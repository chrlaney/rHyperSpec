# Getting Started Guide

This guide has moved to the [Shiny Dev Center](http://shiny.rstudio.com/articles/shinyapps.html).

